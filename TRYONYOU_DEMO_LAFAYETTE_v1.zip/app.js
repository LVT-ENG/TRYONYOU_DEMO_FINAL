const looks = [
  {
    id: 1,
    title: "Look 01 – Futuristic City Night",
    description: "Sculpted blazer, tailored pants, mirror-finish boots. Instant editorial energy.",
    image: "./assets/look1.png",
    thumb: "./assets/look1.png"
  },
  {
    id: 2,
    title: "Look 02 – Daytime Paris Tailoring",
    description: "Soft-shoulder coat, fluid trousers, clean sneakers. Effortless Lafayette chic.",
    image: "./assets/look2.png",
    thumb: "./assets/look2.png"
  },
  {
    id: 3,
    title: "Look 03 – Holographic Evening",
    description: "Liquid-metal dress, structured shoulders, sculptural heels. Red carpet, no cabin.",
    image: "./assets/look3.png",
    thumb: "./assets/look3.png"
  }
];

let currentIndex = 0;

function updateHero() {
  const heroLookImg = document.getElementById("hero-look");
  const heroTitle = document.getElementById("hero-title");
  const heroDescription = document.getElementById("hero-description");
  const look = looks[currentIndex];

  if (!heroLookImg || !heroTitle || !heroDescription) return;

  heroLookImg.src = look.image;
  heroLookImg.alt = look.title;
  heroTitle.textContent = look.title;
  heroDescription.textContent = look.description;

  const cards = document.querySelectorAll(".look-card");
  cards.forEach((card, index) => {
    if (index === currentIndex) {
      card.classList.add("active");
    } else {
      card.classList.remove("active");
    }
  });
}

function createLookCards() {
  const list = document.getElementById("looks-list");
  if (!list) return;

  looks.forEach((look, index) => {
    const card = document.createElement("button");
    card.className = "look-card";
    card.setAttribute("type", "button");
    card.dataset.index = index.toString();

    const thumb = document.createElement("div");
    thumb.className = "look-thumb";

    const img = document.createElement("img");
    img.src = look.thumb;
    img.alt = look.title;
    thumb.appendChild(img);

    const meta = document.createElement("div");
    meta.className = "look-meta";

    const title = document.createElement("h4");
    title.textContent = look.title.replace("Look ", "L");

    const desc = document.createElement("p");
    desc.textContent = look.description;

    meta.appendChild(title);
    meta.appendChild(desc);

    card.appendChild(thumb);
    card.appendChild(meta);

    card.addEventListener("click", () => {
      currentIndex = index;
      updateHero();
    });

    list.appendChild(card);
  });
}

function attachNav() {
  const prevBtn = document.getElementById("prev-look");
  const nextBtn = document.getElementById("next-look");

  if (prevBtn) {
    prevBtn.addEventListener("click", () => {
      currentIndex = (currentIndex - 1 + looks.length) % looks.length;
      updateHero();
    });
  }

  if (nextBtn) {
    nextBtn.addEventListener("click", () => {
      currentIndex = (currentIndex + 1) % looks.length;
      updateHero();
    });
  }
}

window.addEventListener("DOMContentLoaded", () => {
  createLookCards();
  attachNav();
  updateHero();
});
