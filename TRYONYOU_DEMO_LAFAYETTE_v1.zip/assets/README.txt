Place your real assets here, keeping these filenames:
- model.png
- logo-peacock.png
- look1.png
- look2.png
- look3.png
- qr.png
- arrows.svg (optional, not required by app.js)
