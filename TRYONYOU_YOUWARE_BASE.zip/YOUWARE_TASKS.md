# TRYONYOU – ABVETOS – ULTRA–PLUS–ULTIMATUM
# YouWare / Manus working package

Root stack:
- React 18
- Vite 7.1.2
- react-router-dom 7
- SPA, routes defined in src/main.jsx and src/pages/*

Main routes:
- "/" → Home
- "/demo" → Demo
- "/brands" → Brands
- "/intelligent-system" → IntelligentSystem
- "/wardrobe" → Wardrobe
- "/avatar" → Avatar
- "/showroom" → Showroom
- "/lafayette-demo" → LafayetteDemo
- "/station-f" → StationF

Your mission now:

1. Clean and complete all pages
   - Ensure each page in src/pages/ renders a complete, presentable screen:
     - Home.jsx
     - Demo.jsx
     - Brands.jsx
     - IntelligentSystem.jsx
     - Wardrobe.jsx
     - Avatar.jsx
     - Showroom.jsx
     - LafayetteDemo.jsx
     - StationF.jsx
   - No placeholder text.
   - No dead links.
   - All navigation available via the top-level layout.

2. Integrate visual style (DRS–TRYONYOU)
   - Use src/style.css and styles.css as base.
   - Keep:
     - dark anthracite background
     - gold and bone-white accents
     - peacock logo as symbol only (no text)
   - Make sure all pages share the same visual system.

3. Build the sellable demo flow
   - Required flow for the demo:
     - Home → Brands → Showroom → Avatar → Wardrobe → Final Look / Demo
   - There must be a clear CTA button on:
     - Home (Start demo)
     - Brands (Choose brand)
     - Showroom (Enter fitting room)
     - Final Look (Book demo / Contact us)

4. Implement modules

   4.1 Avatar module (Avatar.jsx)
   - Use the existing layout and assets.
   - Show an avatar area where the user “stands”.
   - Show basic controls: gender, style, body mood.
   - This is visual only (no backend).

   4.2 Virtual Wardrobe (Wardrobe.jsx)
   - Use grid of garments (cards).
   - Include at least:
     - Jackets / tops
     - Trousers / skirts
     - Shoes
     - Accessories
   - For now, data can be coded in a local JS file:
     - src/utils/outfits.js or similar

   4.3 Lafayette demo (LafayetteDemo.jsx)
   - Create a page that looks like a premium demo for a department store.
   - Include:
     - hero explaining the experience
     - blocks: “How the demo works”, “What the customer sees”, “What the staff sees”
     - at least 1 carousel or grid of looks.
   - CTA: “Schedule a live demo”.

   4.4 Station F page (StationF.jsx)
   - Explain the startup / tech side.
   - Sections:
     - Problem
     - Solution TRYONYOU
     - Modules (Avatar, Wardrobe, ABVETOS, Deploy Express, etc.)
     - Why now.
   - CTA: “Request deck” or “Open live demo”.

   4.5 Showroom (Showroom.jsx)
   - One full-screen showroom scene.
   - Use existing background assets from the root (JPEG / PNG files already included).
   - Place UI panels over the scene:
     - current avatar
     - selected outfit
     - next recommendations.

5. Navigation and layout
   - Make sure navigation is centralized:
     - Either via a header component
     - Or via a layout wrapper in src/layouts/
   - No page should be isolated.
   - All links must use <Link> from react-router-dom.

6. Delivery expectations
   - The working tree in this ZIP is the base.
   - You work directly on this React project.
   - When finished, deliver:
     - the updated project as a ZIP: TRYONYOU_YOUWARE_DELIVERED.zip
     - with:
       - src/
       - index.html
       - package.json
       - vite.config.js
       - styles.css
   - The project must:
     - run with: npm install && npm run dev
     - build with: npm run build

7. Non-functional requirements
   - No TypeScript.
   - No backend.
   - No design systems (MUI, Chakra, etc.) – only basic CSS.
   - No experimental dependencies.
   - Keep bundle size reasonable.

8. What NOT to touch
   - Do not remove:
     - investor.json
     - any existing background images
     - existing route names.
   - Do not change:
     - project name
     - Vite configuration
     - package.json dependencies (unless strictly needed to fix something).

Thank you.
