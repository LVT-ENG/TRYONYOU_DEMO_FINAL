# Implementation Requirements

1. React + Vite
   - Use React 18.
   - Use Vite 7.1.2.
   - Use @vitejs/plugin-react.

2. Routing
   - Use react-router-dom v6 with BrowserRouter.
   - Define routes in a clean way (no nested chaos).
   - Each route must load a dedicated page component from `src/pages`.

3. Code Quality
   - No unused components.
   - No placeholder components that are never rendered.
   - No commented-out large code blocks in the final delivery.
   - Use functional components and hooks only (no class components).

4. Styling
   - Use a global stylesheet, e.g. `src/assets/styles/global.css` or `styles.css`.
   - Dark, luxurious, futuristic aesthetic.
   - Use the peacock / showroom as the mental model for the style.
   - No random colors; keep it coherent and premium.

5. Deliverable
   - One ZIP with a complete Vite project.
   - Must run with:
     - `npm install`
     - `npm run dev`
     - `npm run build`
   - Build must pass with no errors or missing modules.