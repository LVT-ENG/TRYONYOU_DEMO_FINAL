# Routes Specification

The app must use react-router-dom v6 with BrowserRouter.

Required routes:

- `/`
  - Landing page
  - High-impact hero section with TRYONYOU branding.
  - CTA buttons to `/demo` and `/lafayette-demo`.

- `/demo`
  - General interactive demo of TRYONYOU experience.
  - Short "how it works" explanation and visual flow.

- `/brands`
  - Section for brands / boutiques.
  - Explain value for partners (conversion, returns reduction, premium experience).

- `/intelligent-system`
  - Overview of the TRYONYOU – ABVETOS – ULTRA–PLUS – ULTIMATUM ecosystem.
  - Explain modules at a high level (Smart Wardrobe, Solidarity Wardrobe, payments, orchestration, etc.).

- `/wardrobe`
  - Smart Wardrobe + Solidarity Wardrobe concept page.
  - Show how users can manage their wardrobe and donate / resell.

- `/avatar`
  - Page explaining avatar creation and emotional experience.
  - Pau (the peacock assistant) is mentioned as the guide character.

- `/showroom`
  - Futuristic showroom experience description.
  - This is the visual universe of TRYONYOU (luxury, futuristic, clean).

- `/lafayette-demo`
  - Specific demo page for a department store like Galeries Lafayette.
  - Clear, polished, investor / partner facing explanation.
  - One-click path to start a private demo call or contact.

Navigation:
- Use a top navigation bar with links to all main routes.
- Highlight the current active route.