TRYONYOU – ABVETOS – ULTRA–PLUS – ULTIMATUM
MASTER SPEC PACKAGE FOR FIVERR DEVELOPER

This ZIP does NOT contain the final React code.
It contains the OFFICIAL SPECIFICATION the developer MUST follow
to build the production-ready React + Vite SPA.

1. Open the folder `specs/` and read ALL files first.
2. Then create a new React + Vite 7.1.2 project.
3. Implement the routes, components and layouts exactly as described.
4. Final delivery must be a clean, production-ready SPA.

All project content, comments and code must be in ENGLISH.