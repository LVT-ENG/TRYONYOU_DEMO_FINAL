import React from "react";

export default function HeroSection() {
  return (
    <section className="hero-shell">
      <div className="hero-left">
        <p className="hero-kicker">Futuristic Fashion Operating System</p>
        <h1 className="hero-title">
          TRYONYOU makes every outfit feel made only for you.
        </h1>
        <p className="hero-subtitle">
          Capture your avatar once, then let PAU, Smart Wardrobe and ABVETOS orchestrate the perfect look for every moment.
        </p>
        <div className="hero-actions">
          <a href="#start-demo" className="hero-cta-primary">Start Demo Flow</a>
          <a href="#modules" className="hero-cta-secondary">Explore Modules</a>
        </div>
        <div className="hero-meta">
          <span>Avatar-first sizing</span>
          <span>Real-time trend tracking</span>
          <span>No more wrong purchases</span>
        </div>
      </div>

      <div className="hero-right">
        <div className="hero-scene">
          <div className="hero-scene-floor"></div>
          <div className="hero-avatar-pedestal">
            <div className="hero-avatar-silhouette"></div>
            <div className="hero-avatar-glow"></div>
          </div>
          <div className="hero-pau-orb">
            <div className="hero-pau-inner"></div>
          </div>
          <div className="hero-pill hero-pill-left">
            <p className="hero-pill-label">Smart Wardrobe</p>
            <p className="hero-pill-text">Personal archive with fit memory and emotional tags.</p>
          </div>
          <div className="hero-pill hero-pill-right">
            <p className="hero-pill-label">ABVET Payment</p>
            <p className="hero-pill-text">Biometric checkout integrated with wardrobe memory.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
