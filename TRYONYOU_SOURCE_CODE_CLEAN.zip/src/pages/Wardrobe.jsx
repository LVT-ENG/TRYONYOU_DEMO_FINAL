import React from "react";
import VirtualWardrobe from "../components/VirtualWardrobe";

export default function Wardrobe() {
  return <VirtualWardrobe />;
}
