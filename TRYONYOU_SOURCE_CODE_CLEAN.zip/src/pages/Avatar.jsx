import React from "react";
import Avatar3D from "../components/Avatar3D";

export default function Avatar() {
  return <Avatar3D />;
}
