export default function Demo(){
  return (
    <div style={{padding: 40, fontFamily: 'sans-serif'}}>
      <h1>Demo Page</h1>
      <p>Extended content will be added later.</p>
    </div>
  );
}
