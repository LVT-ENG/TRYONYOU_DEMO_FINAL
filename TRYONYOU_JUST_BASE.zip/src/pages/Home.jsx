export default function Home(){
  return (
    <div style={{padding: 40, fontFamily: 'sans-serif'}}>
      <h1>TRYONYOU – Base Setup</h1>
      <p>This is the clean starting point.</p>
    </div>
  );
}
