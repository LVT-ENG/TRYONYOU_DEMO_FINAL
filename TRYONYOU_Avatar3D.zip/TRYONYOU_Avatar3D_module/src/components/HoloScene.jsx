import React, { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { PerspectiveCamera, Environment } from "@react-three/drei";
import HoloControls from "./HoloControls";
import HoloLighting from "./HoloLighting";
import AvatarModel from "./AvatarModel";

export default function HoloScene({ selectedOutfit }) {
  return (
    <div style={styles.container}>
      <Canvas
        shadows
        gl={{ antialias: true, alpha: true }}
        style={styles.canvas}
      >
        <PerspectiveCamera makeDefault position={[0, 1.5, 3]} fov={50} />

        <HoloLighting />
        <HoloControls />

        {/* Plataforma de presentación */}
        <mesh
          position={[0, 0, 0]}
          rotation={[-Math.PI / 2, 0, 0]}
          receiveShadow
        >
          <cylinderGeometry args={[2, 2, 0.1, 64]} />
          <meshStandardMaterial
            color="#f5f5f5"
            metalness={0.3}
            roughness={0.4}
          />
        </mesh>

        {/* Avatar 3D */}
        <Suspense fallback={null}>
          <AvatarModel outfit={selectedOutfit} />
        </Suspense>

        {/* Ambiente */}
        <Environment preset="studio" />
      </Canvas>
    </div>
  );
}

const styles = {
  container: {
    width: "100%",
    height: "500px",
    borderRadius: "12px",
    overflow: "hidden",
    boxShadow: "0 8px 32px rgba(0, 0, 0, 0.1)",
  },
  canvas: {
    width: "100%",
    height: "100%",
  },
};
